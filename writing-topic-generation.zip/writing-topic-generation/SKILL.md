---
name: writing-topic-generation
description: "Forecasts the next 30 most likely topics for Daily Micro Fiction from the story tracker's own base rates, recency, calendar anchors and gap analysis, and scores past forecasts against what actually published. Use whenever the user asks what to write about next, wants topic or story ideas, an editorial calendar, or a read on what the publication has never covered. Trigger on casual phrasings too: \"what should I write next,\" \"give me topic ideas,\" \"I'm out of ideas,\" \"what haven't I written about,\" \"what's coming up,\" \"did my forecast hold up.\""
---

# Writing Topic Generation

Produce a ranked forecast of the **next 30 topics** Daily Micro Fiction is most
likely to publish, derived from `DMF_Story_Tracker.xlsx` rather than from
intuition. The output is a standalone markdown file that sits beside the tracker
and can be scored later against what actually ran.

**Default N is 30.** The user may ask for another number; the method is
unchanged, only the slot math rescales.

**Two modes.** `Forecast` builds a new one. `Score` grades an existing forecast
against rows the tracker has gained since. Score mode is the point of the
whole exercise, so offer it whenever an unscored forecast exists.

## Relationship to dmf-story-tracker-update

This skill is the tracker's downstream consumer. It reads, and never writes, the
workbook.

- **Freshness gates the run.** Compare the tracker's newest row date to today. A
  gap wider than seven days means the earliest forecast slots are already spent
  and the forecast will be wrong at the top. Say so, and offer to run
  `dmf-story-tracker-update` first. Proceed on a stale tracker only if the user
  declines, and then record the gap in the output header.
- **Never edit the workbook.** That skill's invariant is that the tracker is
  regenerated, never hand-edited. Do not add a sheet, do not call openpyxl's
  `insert_rows`, do not touch the Summary formulas. The forecast is a sibling
  `.md` file, not a tab.
- **The forecast is a derived artifact.** It falls under that skill's invariant
  that anything tracker-derived living elsewhere is regenerated when the tracker
  is. A forecast whose stamp predates the tracker's newest row is stale by
  definition.
- **Profiling depth is the input quality.** Gap analysis reads Notes, Setting
  and Characters, so unprofiled rows are invisible to it beyond their bare tag.
  When the tracker's profiling backlog is non-trivial, say which part of the
  catalogue the gap analysis could not see.
- **Handoff downstream.** A chosen topic becomes the Thesis input to
  `dmf-story`, which needs five inputs. Pass the topic and any setting the
  rationale implies; let that skill gather the rest. Do not draft the story here.

## Shared column contract

From the Story Tracker sheet, data from row 5 down.

| Col | Header | Use here |
| --- | --- | --- |
| B | `Date` | Cadence, recency, seasonality |
| C | `Title` | Keyword probing for gap analysis |
| D | `Topic` | The primary signal |
| G | `Word Count` | Ignored |
| H, I, J, K | Profile columns | Semantic gap analysis |

**Split `Topic` on semicolons.** The Summary sheet's tag counts match on whole
tags, so `cats; foom` counts once under each. Exact-string matching undercounts
`foom` by roughly five and will quietly distort the whole slot allocation.

## Style rules

Inherited from `dmf-story` and `dmf-story-tracker-update`, and they apply to
every rationale this skill writes.

- **Minimize em dashes.** Commas, semicolons or periods.
- **No negative parallelism.** Nothing of the form "not X but Y," "less about X
  than Y." State the affirmation directly.
- **Prose, not shorthand.** Rationales are sentences.
- **No false precision.** Probabilities are round betting lines. Say so.

## Forecast procedure

### 1. Stage and gate

Stage the workbook from the connected Projects folder and record the returned
`mtimeMs`; it becomes the forecast's provenance stamp. Read the newest row date
and the row count. Apply the freshness gate above.

### 2. Fix the window

Compute posts per day over the current calendar year, dividing by elapsed days
rather than by month count, since the newest month is partial. N divided by that
rate gives the window in days. Name every fixed-date anchor that falls inside
it: holidays, elections, awards announcements, sporting finals, the clock
change, equinoxes. The calendar does much of the forecasting, and unlike the
rest of the method it is knowable in advance.

### 3. Establish base rates

Compute and report:

- Distinct tag strings against total rows.
- **Brand-new tag rate** over the last 100 and last 50 posts. This is the single
  most load-bearing figure in the method.
- For each tag with four or more lifetime uses: lifetime share, current-year
  share, and trailing-quarter share.

### 4. Allocate the slots

House tags get counts, not ranks. For each, blend the lifetime share with the
trailing-quarter share and multiply by N. Fill the remainder with warm repeats
and brand-new tags in the ratio the brand-new rate implies.

Worked example at N=30, on the August 2026 corpus:

| Block | Slots | Derivation |
| --- | ---: | --- |
| `foom` | 5 | 13.9% lifetime blended with 27.8% trailing quarter |
| `cats` | 2 | 6% lifetime |
| `benchmarking` | 1 | roughly monthly when active |
| `Ukraine` | 1 | 5 uses in-year |
| `meta bullshit` / `reports` | 1 | publication-about-itself cadence |
| Warm repeats | 4 | long-dormant tags with real history |
| **Brand-new tags** | **16** | 53% brand-new rate |

Recompute these from the live sheet every run. The rates drift, and `foom` in
particular has trended up.

### 5. Recency

Days since last use for every repeat tag. A high-count tag with an unusually
long dry spell is the strongest repeat signal available, stronger than raw
frequency. Flag any tag whose current gap exceeds its own historical median.

### 6. Gap analysis

The part that produces surprises. Probe the whole corpus, Topic and Title
together, with a keyword list spanning the lanes the publication plainly cares
about, and collect the ones returning zero. Probe at minimum:

- **Calendar** against the holidays already tagged.
- **AI research and governance** vocabulary, tested against the volume of AI
  fiction already published.
- **The user's profession**, currently parenteral manufacturing and regulatory
  affairs.
- **Hobbies and home**, the reset-valve topics that follow a dense run.
- **Geography**, especially large countries with no tag.
- **Sport, science and environment** against their existing neighbours.

A zero is interesting only in contrast. "No Halloween" matters because ten other
holidays are tagged; "no interpretability" matters because the catalogue holds
eighty foom stories. Report the contrast, not the bare absence.

### 7. The news layer

WebSearch the live cycle, weighted toward the user's Tier 0 feeds: AI policy,
safety and forecasting, progress and economics writing, and the SFF magazines.
A topic with a dated hook inside the window outranks one without.

### 8. The personal layer

Check memory for profession, location, hobbies, travel and the cats before
ranking. These decide several slots outright, and they are the difference
between a forecast for this publication and a forecast for any publication.

### 9. Rank and write

Rank by probability the tag appears at least once in the window. Use bands and
say they are bands: 80%+ near-certain, 50-79% likely, 30-49% even money, 15-29%
live long shot. Nothing below 15% earns a slot.

## Output format

One markdown file, `DMF_Topic_Forecast_<N>_<YYYYMMDD>.md`, beside the tracker.
Sections, in order:

1. **Provenance header.** Tracker row count, newest row date, staged `mtimeMs`,
   generation date, window covered, and any freshness gap.
2. **The window.** Cadence arithmetic and the calendar anchors inside it.
3. **The slot math.** Base-rate table and the allocation table.
4. **The ranked N.** A table: rank, tag, probability, last used, one-sentence
   rationale.
5. **Reading the list.** Which ranks are accounting, which are calendar, which
   are structural gaps, which are reset valves.
6. **Considered and left off.** Near-misses with the reason, so the next run
   does not re-derive them.

Deliver with `SendUserFile`, then `device_commit_files` into the Projects
folder beside the tracker.

## Score procedure

Run this whenever the tracker has advanced past an existing forecast's stamp.

1. Read the newest forecast file and its stamp.
2. Stage the current tracker. Take every row dated after the stamp, up to the
   forecast's N.
3. Mark each forecast row hit or miss. A hit is the tag appearing at least once;
   for house tags also compare predicted count against actual.
4. Compute hit rate **by band**. Calibration means the 70% band lands near 70%,
   so a band that comes in at 95% was under-confident and one at 30% was over-
   confident.
5. Report the misses that mattered and any topic that ran and appeared nowhere
   on the list. Those are the method's blind spots and the most useful output
   of the whole loop.
6. Carry the band corrections into the next forecast and say that you did.

## Invariants

- **Read-only on the workbook.** No sheets, no rows, no formula edits, ever.
- **Whole-tag semantics.** Split on semicolons, matching the Summary formulas.
- **Every forecast carries its provenance stamp.** A forecast that cannot be
  dated against a tracker state cannot be scored, which makes it decoration.
- **House tags get counts, not ranks.** Predicting that `foom` will appear is
  not a prediction. The count and the timing are.
- **Half the list will be tags that have never existed.** If the brand-new share
  of the output is far below the corpus's brand-new rate, the forecast has
  collapsed onto the familiar and needs redoing.
- **Never draft the story here.** Hand off to `dmf-story`.

## Version control and maintenance

Current version **v1.0**. On any modification, bump one whole number and add an
entry to the Changelog below recording the version, the date, what changed and
why. A version bump without a changelog entry is an incomplete change.

**SKILL.md has a hard ceiling of 250 lines.** Anything past it moves to a
`references/` file, and a reference file is named here only once it exists.

## Changelog

- **v1.0**, 12 Sep 2026. Initial version, generalized from a 50-topic forecast
  run against the 568-row tracker. Established the slot-math method, the
  gap-analysis probe list, the provenance stamp and the scoring loop with
  `dmf-story-tracker-update`.